"""Regression tests for scientific scoring, paired tests and reproducibility."""
import unittest
import unicodedata
import numpy as np
from statsmodels.stats.multitest import multipletests
from scoring import category,score,value_of,BLOCKS
from data_pipeline import load_corrected
from models import design,fit,frame,observed_effect,population_effect,intervals
from statsmodels.genmod.bayes_mixed_glm import BinomialBayesMixedGLM

class ReleaseTests(unittest.TestCase):
    def test_every_unicode_decimal_block(self):
        # Exhaustive over all decimal characters supported by this interpreter.
        count=0
        for code in range(0x110000):
            c=chr(code);v=unicodedata.decimal(c,None)
            if v is None:continue
            count+=1
            self.assertEqual(value_of(c),str(v))
            for system,(lo,hi) in BLOCKS.items():
                expected="A_preserved" if lo<=code<=hi else "B_all_western" if 0x30<=code<=0x39 else "D_substitution"
                self.assertEqual(category(system,c),expected)
                self.assertNotEqual(category(system,c),"E_no_digit")
        self.assertGreater(count,600)

    def test_recorded_failures_and_nondecimal(self):
        self.assertEqual(score("arabic","٣０","30")["joint_correct"],False)
        self.assertEqual(category("arabic","٣０"),"D_substitution")
        self.assertEqual(category("devanagari","๔๕"),"D_substitution")
        self.assertEqual(category("arabic","٣0"),"C_mixed")
        self.assertEqual(category("arabic","no number ²"),"E_no_digit")
        self.assertEqual(category("western","30"),"A_preserved")

    def test_audited_counts(self):
        rows,changes,gates=load_corrected()
        self.assertEqual(len(changes),22)
        self.assertEqual(sum(r["arm"]=="core" for r in rows),4000)
        self.assertEqual(sum(r["arm"]=="robust" and not r["retained"] for r in rows),1000)
        expected={"neutral":(41,424,112),"preserve":(33,305,93)}
        for prompt,counts in expected.items():
            rs=[r for r in rows if r["arm"]=="core" and r["system"]!="western" and r["prompt"]==prompt]
            self.assertEqual((sum(r["joint_correct"] for r in rs),sum(not r["emits_digit"] for r in rs),sum(r["script_preserved"] for r in rs)),counts)
        self.assertEqual(len(frame("h1_arabic",rows)),344)
        self.assertEqual(len(frame("h1_pooled",rows)),861)
        self.assertEqual(len(frame("h2_script",rows)),2271)

    def test_holm_known_counterexample(self):
        np.testing.assert_allclose(multipletests([.03,.031,.032],method="holm")[1],[.09,.09,.09])

    def test_basic_reflection_and_threshold_direction(self):
        out=intervals(-12.,np.array([-25.,-20.,-15.,-10.]))
        pct=out["percentile"]["ci95_pp"];basic=out["basic"]["ci95_pp"]
        np.testing.assert_allclose(basic,[-24-pct[1],-24-pct[0]])
        self.assertFalse(intervals(0,np.array([-2.,-1.,1.,2.]))["percentile"]["mechanical_rules_only"]["nonzero_two_sided95"])

    def test_model_design_and_repeated_fit(self):
        rows,_,_=load_corrected();df=frame("h1_arabic",rows);X,Z,ids=design(df)
        np.testing.assert_array_equal(np.asarray(Z.sum(axis=1)).ravel(),np.full(len(df),2))
        a,_=fit(df.y,X,Z,ids);b,_=fit(df.y,X,Z,ids)
        np.testing.assert_allclose(a.params,b.params,rtol=0,atol=1e-10)
        effect=observed_effect(a.fe_mean,np.asarray(Z@a.vc_mean).ravel())
        self.assertTrue(-18<effect<-16)
        self.assertLess(abs(population_effect(a.fe_mean,a.vcp_mean,80)-population_effect(a.fe_mean,a.vcp_mean,160)),.005)

    def test_explicit_design_against_formula_interface(self):
        rows,_,_=load_corrected()
        for name in ["h1_arabic","h2_joint"]:
            df=frame(name,rows);X,Z,ids=design(df);explicit,_=fit(df.y,X,Z,ids)
            m=BinomialBayesMixedGLM.from_formula('y ~ x',{'value':'0 + C(value)','model':'0 + C(model)'},df,vcp_p=1.,fe_p=2.)
            k=m.k_fep+m.k_vcp+m.k_vc
            formula=m.fit_vb(mean=np.zeros(k),sd=np.full(k,.6),minim_opts={'maxiter':1000,'gtol':1e-5})
            a=observed_effect(explicit.fe_mean,np.asarray(Z@explicit.vc_mean).ravel())
            b=observed_effect(formula.fe_mean,np.asarray(m.exog_vc@formula.vc_mean).ravel())
            self.assertTrue(formula.optim_retvals.success)
            self.assertLess(abs(a-b),1e-5)

if __name__=="__main__":unittest.main(verbosity=2)
