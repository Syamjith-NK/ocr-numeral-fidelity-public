"""Unicode-decimal scoring; shared by rescoring and future evaluation runs."""
import unicodedata

BLOCKS = {"western": (0x30, 0x39), "arabic": (0x660, 0x669),
          "persian": (0x6F0, 0x6F9), "devanagari": (0x966, 0x96F)}
CATEGORIES = ("A_preserved", "B_all_western", "C_mixed", "D_substitution", "E_no_digit")

def decimal_chars(text):
    return [c for c in text if unicodedata.decimal(c, None) is not None]

def value_of(text):
    return "".join(str(unicodedata.decimal(c)) for c in decimal_chars(text))

def category(source, text):
    if source not in BLOCKS:
        raise ValueError("Unknown input numeral system: " + source)
    chars = decimal_chars(text)
    if not chars:
        return "E_no_digit"
    lo, hi = BLOCKS[source]
    own = [lo <= ord(c) <= hi for c in chars]
    western = [0x30 <= ord(c) <= 0x39 for c in chars]
    if all(own):
        return "A_preserved"
    if all(western):
        return "B_all_western"
    if all(a or b for a, b in zip(own, western)):
        return "C_mixed"
    return "D_substitution"

def score(source, text, intended):
    read = value_of(text)
    cat = category(source, text)
    correct = read == intended
    return {"read": read, "value_correct": correct, "category": cat,
            "script_preserved": cat == "A_preserved",
            "joint_correct": correct and cat == "A_preserved",
            "emits_digit": bool(decimal_chars(text))}
