#!/usr/bin/env python3
"""Confirmatory evaluation. Protocol frozen 2026-10-08T03:51:04Z.

Stimuli come from values.json (seed 20261008); nothing here invents a value.
Both prompts are verbatim from the pre-registration. Scoring is value-based plus
script category, exactly as the pilot, so the two remain comparable though they
are NEVER pooled.

Every trial is written out with its RAW output. Western controls are rendered in
the same typeface and size as the script they gate, and a model x typeface cell
whose Western control falls below 90% is flagged — flagged, not dropped: the
rows stay in the file and the exclusion happens at analysis time.

    python confirm_run.py <hf-model-id> [--arm core|robust]
"""

from __future__ import annotations

import argparse, collections, json, time, unicodedata
from pathlib import Path

import torch
from PIL import Image, ImageDraw, ImageFont
from transformers import AutoModelForImageTextToText, AutoProcessor

HERE = Path(__file__).parent
S = "/System/Library/Fonts/Supplemental/"
SYSF = "/System/Library/Fonts/"

SYSTEMS = {"western":"0123456789","arabic":"٠١٢٣٤٥٦٧٨٩",
           "persian":"۰۱۲۳۴۵۶۷۸۹","devanagari":"०१२३४५६७८९"}
from scoring import category, value_of
PROMPTS = {
 "neutral":  "Extract the text from this image exactly as written. Output only the text.",
 "preserve": "Extract the text from this image exactly as written, keeping the "
             "original numeral characters unchanged. Output only the text.",
}
CORE_FONT, CORE_SIZE = S+"Arial Unicode.ttf", 72
ROBUST = [(S+"Arial Unicode.ttf",48),(S+"Arial Unicode.ttf",96),
          (S+"Al Nile.ttc",48),(S+"Al Nile.ttc",96),
          (SYSF+"GeezaPro.ttc",48),(SYSF+"GeezaPro.ttc",96)]

def convert(v,sys_): t=SYSTEMS[sys_]; return "".join(t[int(c)] for c in v)
def render(text,font_path,size):
    f=ImageFont.truetype(font_path,size)
    d0=ImageDraw.Draw(Image.new("L",(1,1)))
    b=d0.textbbox((0,0),text,font=f)
    if b[2]-b[0]<2: return None
    im=Image.new("L",(b[2]-b[0]+80,b[3]-b[1]+80),255)
    ImageDraw.Draw(im).text((40-b[0],40-b[1]),text,font=f,fill=0)
    return im

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("model"); ap.add_argument("--arm",default="core",choices=["core","robust"])
    ap.add_argument("--revision",required=True,help="Exact model commit hash, not a moving branch")
    ap.add_argument("--output-dir",type=Path,required=True,help="New directory for this evaluation; archived raw data are never overwritten")
    a=ap.parse_args()
    import re, hashlib
    if not re.fullmatch(r"[0-9a-f]{40}",a.revision): ap.error("--revision must be a 40-character model commit hash")
    if a.output_dir.exists(): ap.error("--output-dir must not already exist")
    a.output_dir.mkdir(parents=True)
    vals=json.loads((HERE.parent/"data"/"values.json").read_text(encoding="utf-8"))
    rows_v=vals["values"]
    if a.arm=="robust":
        rows_v=rows_v[:25]; conds=ROBUST; prompts=["neutral"]
    else:
        conds=[(CORE_FONT,CORE_SIZE)]; prompts=["neutral","preserve"]

    dev="mps" if torch.backends.mps.is_available() else "cpu"
    dtype=torch.bfloat16 if dev=="mps" else torch.float32
    proc=AutoProcessor.from_pretrained(a.model,revision=a.revision)
    model=AutoModelForImageTextToText.from_pretrained(a.model,revision=a.revision,dtype=dtype).to(dev).eval()
    print(f"{a.model} | arm={a.arm} | {dev}/{dtype} | {len(rows_v)} values",flush=True)

    def ask(im,prompt):
        msgs=[{"role":"user","content":[{"type":"image"},{"type":"text","text":prompt}]}]
        t=proc.apply_chat_template(msgs,tokenize=False,add_generation_prompt=True)
        i=proc(text=[t],images=[im.convert("RGB")],return_tensors="pt").to(dev)
        with torch.no_grad(): o=model.generate(**i,max_new_tokens=32,do_sample=False)
        return proc.decode(o[0][i["input_ids"].shape[1]:],skip_special_tokens=True).strip()

    out=[]; t0=time.time(); n=0
    total=len(rows_v)*len(SYSTEMS)*len(conds)*len(prompts)
    for fp,size in conds:
        for pname in prompts:
            for rv in rows_v:
                for sys_ in SYSTEMS:
                    im=render(convert(rv["value"],sys_),fp,size)
                    if im is None: continue
                    got=ask(im,PROMPTS[pname]); read=value_of(got)
                    out.append({"model":a.model,"arm":a.arm,"font":Path(fp).stem,"size":size,
                        "prompt":pname,"value":rv["value"],"stratum":rv["stratum"],
                        "digits":rv["digits"],"has_repeat":rv["has_repeat"],
                        "has_confusable":rv["has_confusable"],"system":sys_,
                        "shown":convert(rv["value"],sys_),"raw_output":got,"read":read,
                        "value_correct":read==rv["value"],
                        "category":category(sys_,got),
                        "script_preserved":category(sys_,got)=="A_preserved",
                        "joint_correct":read==rv["value"] and category(sys_,got)=="A_preserved"})
                    n+=1
                    if n%100==0:
                        print(f"  {n}/{total}  {time.time()-t0:.0f}s",flush=True)
    # western control gate, per font — flagged, never dropped here
    gate={}
    for fname in {r["font"] for r in out}:
        w=[r for r in out if r["font"]==fname and r["system"]=="western"]
        ok=sum(r["value_correct"] for r in w)
        gate[fname]={"correct":ok,"n":len(w),"rate":ok/len(w) if w else 0,
                     "passes_90pct":bool(w) and ok/len(w)>=0.90}
    tag=a.model.split("/")[-1].replace(".","_")
    dest=a.output_dir/f"confirm_{a.arm}_{tag}.json"
    dest.write_text(json.dumps({"model":a.model,"arm":a.arm,"dtype":str(dtype),
        "device":dev,"historical_protocol_frozen":"2026-10-08T03:51:04Z",
        "evaluation_status":"NEW RUN, not part of the 2026-10-08 archived dataset",
        "model_revision":a.revision,"font_sha256":{fp:hashlib.sha256(Path(fp).read_bytes()).hexdigest() for fp,size in conds},
        "western_control":gate,"rows":out},ensure_ascii=False,indent=2),encoding="utf-8")
    for f,g in gate.items():
        print(f"  control {f[:18]:20s} {g['correct']}/{g['n']} "
              f"{'PASS' if g['passes_90pct'] else 'FAIL — flagged'}")
    print(f"  {len(out)} trials in {time.time()-t0:.0f}s -> {dest.name}")

if __name__=="__main__": raise SystemExit(main())
