"""One-command reanalysis. Outputs always go to an explicit new directory."""
import os
for name in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","VECLIB_MAXIMUM_THREADS"):
    os.environ[name]="1"
import argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import platform
import numpy,pandas,scipy,statsmodels
from data_pipeline import write_rescoring,dump_json
from descriptive import run as describe
from models import SPECS,run_job

def main():
    p=argparse.ArgumentParser();p.add_argument("--out",type=Path,required=True)
    p.add_argument("--draws",type=int,default=2000);p.add_argument("--workers",type=int,default=3)
    p.add_argument("--descriptive-only",action="store_true");args=p.parse_args()
    if args.out.exists() and any(args.out.iterdir()):raise SystemExit("Output directory must be empty; existing evidence is not overwritten.")
    args.out.mkdir(parents=True,exist_ok=True)
    rows=write_rescoring(args.out);describe(rows,args.out)
    env={"python":platform.python_version(),"numpy":numpy.__version__,"pandas":pandas.__version__,"scipy":scipy.__version__,"statsmodels":statsmodels.__version__,
         "bootstrap_draws":args.draws,"workers":args.workers,"model_priors":{"fe_sd":2.,"log_random_sd_sd":1.},"initial_vb_sd":.6,
         "release_status":"HOLD: analysis candidate; see RELEASE_STATUS.txt"}
    dump_json(args.out/"environment.json",env)
    if args.descriptive_only:return
    jobs=[(name,scheme,args.draws,args.out) for name in SPECS for scheme in ("observed","population")]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for f in as_completed([pool.submit(run_job,j) for j in jobs]):print(f.result(),flush=True)
    print("All analyses finished; optimizer failures would have stopped this run.",flush=True)

if __name__=="__main__":main()
