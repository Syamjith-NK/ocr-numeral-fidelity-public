#!/usr/bin/env python3
"""Generate the 100 independent test values fixed by the pre-registration.

Seed 20261008, recorded in PREREGISTRATION_FROZEN.txt before any value existed.
Constraints come from the frozen protocol, not from convenience:

  three length strata   short 1-2 digits, medium 3-4, long 5-6
  digit frequency       each of 0-9 appears comparably often across the set
  repeated digits       a share of values contain a repeated digit
  confusables           a share contain the pairs the pilot showed are fragile:
                        zero against five, and six against seven
  disjoint from pilot   none of 2026, 1445, 7, 350, 1990 may appear

⛔ Generated and validated WITHOUT running any model. Validation here inspects
the dataset only — never an outcome.
"""

from __future__ import annotations

import collections
import json
import random
from pathlib import Path

HERE = Path(__file__).parent
SEED = 20261008
N = 100
PILOT = {"2026", "1445", "7", "350", "1990"}
STRATA = {"short": (1, 2), "medium": (3, 4), "long": (5, 6)}
PER = {"short": 33, "medium": 33, "long": 34}
CONFUSABLE = ({"0", "5"}, {"6", "7"})


def has_confusable(v: str) -> bool:
    d = set(v)
    return any(pair <= d for pair in CONFUSABLE)


def generate():
    """Constrained SELECTION over the full candidate pool, not rejection sampling.

    The first implementation used rejection sampling with quotas and deadlocked
    at 94 values: a 1-digit number cannot contain a repeated digit or a
    confusable PAIR, so the short stratum could never satisfy quotas defined for
    longer strings. Fixed before any data was collected. Quotas now apply only
    to the sub-pool where they are satisfiable.
    """
    rng = random.Random(SEED)
    out = []
    for stratum, (lo, hi) in STRATA.items():
        want = PER[stratum]
        pool = []
        for n in range(lo, hi + 1):
            lowest = 0 if n == 1 else 10 ** (n - 1)
            highest = 10 ** n
            pool.extend(str(v) for v in range(lowest, highest))
        pool = [v for v in pool if v not in PILOT]
        rng.shuffle(pool)

        reps = [v for v in pool if len(set(v)) < len(v)]
        cons = [v for v in pool if has_confusable(v)]
        chosen, seen = [], set()

        def take(src, k):
            for v in src:
                if len(chosen) >= want or k <= 0:
                    return k
                if v in seen:
                    continue
                seen.add(v); chosen.append(v); k -= 1
            return k

        # quotas only as far as the pool allows, then free draws
        take(reps, min(want // 3, len(reps)))
        take(cons, min(want // 3, len(cons)))
        take(pool, want - len(chosen))
        assert len(chosen) == want, f"{stratum}: pool too small ({len(chosen)}/{want})"

        # Balance digit frequency by swapping. The quota pass alone left a 1.9x
        # spread across 0-9 (25 vs 48), and the protocol requires each digit to
        # appear comparably often - if some digits are intrinsically harder, an
        # unbalanced set confounds difficulty with digit identity.
        def spread(sel):
            c = collections.Counter(ch for v in sel for ch in v)
            for d in "0123456789":
                c.setdefault(d, 0)
            return max(c.values()) - min(c.values())
        rest = [v for v in pool if v not in seen]
        improved = True
        while improved:
            improved = False
            base = spread(chosen)
            for i in range(len(chosen)):
                for cand in rest[:400]:
                    trial = chosen[:i] + [cand] + chosen[i+1:]
                    # a swap must not break the stratum's repeat/confusable mix
                    if (len(set(cand)) < len(cand)) != (len(set(chosen[i])) < len(chosen[i])):
                        continue
                    if has_confusable(cand) != has_confusable(chosen[i]):
                        continue
                    if spread(trial) < base:
                        rest.append(chosen[i]); rest.remove(cand)
                        chosen = trial; base = spread(chosen); improved = True
                        break
                if improved:
                    break
        out.extend({"value": v, "stratum": stratum, "digits": len(v),
                    "has_repeat": len(set(v)) < len(v),
                    "has_confusable": has_confusable(v),
                    "has_zero": "0" in v} for v in chosen)
    return out


def validate(rows):
    print(f"  n = {len(rows)}")
    assert len(rows) == N, f"expected {N}"
    vals = [r["value"] for r in rows]
    assert len(set(vals)) == N, "duplicate values"
    assert not (set(vals) & PILOT), "pilot value leaked into the confirmatory set"
    by = collections.Counter(r["stratum"] for r in rows)
    print(f"  strata            {dict(by)}")
    freq = collections.Counter(c for v in vals for c in v)
    lo, hi = min(freq.values()), max(freq.values())
    print(f"  digit frequency   min {lo} max {hi} over 0-9  -> {dict(sorted(freq.items()))}")
    print(f"  with a repeat     {sum(r['has_repeat'] for r in rows)}/{N}")
    print(f"  with a confusable {sum(r['has_confusable'] for r in rows)}/{N}")
    print(f"  containing zero   {sum(r['has_zero'] for r in rows)}/{N}")
    assert hi / max(lo, 1) < 2.5, "digit frequency too unbalanced"
    print("  disjoint from pilot: yes")
    return True


if __name__ == "__main__":
    rows = generate()
    validate(rows)
    (HERE.parent / "data" / "values.json").write_text(
        json.dumps({"seed": SEED, "n": N, "strata": STRATA,
                    "excluded_pilot_values": sorted(PILOT), "values": rows},
                   ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"\n  wrote values.json  (seed {SEED})")
    print("  sample:", ", ".join(r["value"] for r in rows[:8]), "...")
