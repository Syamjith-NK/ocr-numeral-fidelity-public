"""Two explicitly different estimands; neither silently declared pre-registered.

observed: equal-observation standardization using fitted observed random effects;
          conditional outcome bootstrap holds these effects and the design fixed.
population: integrate Gaussian random effects, and redraw entire cluster effects
            during the parametric bootstrap. The statistic uses that same
            integrated functional at every refit. This is a new sensitivity target.
"""
import warnings
import numpy as np
import pandas as pd
from scipy.special import expit
from scipy.sparse import csr_matrix
from numpy.polynomial.hermite import hermgauss
from statsmodels.genmod.bayes_mixed_glm import BinomialBayesMixedGLM
from data_pipeline import dump_json,dump_csv,load_corrected

SPECS={
 "h1_arabic":{"role":"protocol H1 population; inference amended", "outcome":"value_correct","h1":True,"arabic":True,"seed":12001},
 "h1_pooled":{"role":"exploratory three-script pooling", "outcome":"value_correct","h1":True,"arabic":False,"seed":12002},
 "h2_joint":{"role":"H2 primary outcome; inference amended", "outcome":"joint_correct","h1":False,"arabic":False,"seed":12003},
 "h2_value":{"role":"H2 secondary outcome", "outcome":"value_correct","h1":False,"arabic":False,"seed":12004},
 "h2_script":{"role":"H2 secondary; conditional on emitting a decimal digit, post-treatment selection", "outcome":"script_preserved","h1":False,"arabic":False,"seed":12005}}

def frame(name,rows):
    spec=SPECS[name]
    rs=[r for r in rows if r["arm"]=="core" and r["retained"] and r["system"]!="western"]
    if spec["arabic"]:rs=[r for r in rs if r["system"]=="arabic"]
    if spec["h1"]:rs=[r for r in rs if r["prompt"]=="neutral" and r["category"] in ("A_preserved","B_all_western")]
    if name=="h2_script":rs=[r for r in rs if r["emits_digit"]]
    return pd.DataFrame({"y":[int(r[spec["outcome"]]) for r in rs],
                         "x":[int(r["category"]=="B_all_western" if spec["h1"] else r["prompt"]=="preserve") for r in rs],
                         "value":[r["value"] for r in rs],"model":[r["model"] for r in rs]})

def design(df):
    X=np.column_stack([np.ones(len(df)),df.x.to_numpy()])
    v,vals=pd.factorize(df.value,sort=True);m,mods=pd.factorize(df.model,sort=True)
    n=len(df);nv=len(vals);nm=len(mods)
    Z=csr_matrix((np.ones(2*n),(np.r_[np.arange(n),np.arange(n)],np.r_[v,nv+m])),shape=(n,nv+nm))
    return X,Z,np.r_[np.zeros(nv,dtype=int),np.ones(nm,dtype=int)]

def fit(y,X,Z,ident):
    model=BinomialBayesMixedGLM(np.asarray(y),X,Z,ident,vcp_p=1.,fe_p=2.)
    k=model.k_fep+model.k_vcp+model.k_vc
    with warnings.catch_warnings(record=True) as ws:
        warnings.simplefilter("always")
        res=model.fit_vb(mean=np.zeros(k),sd=np.full(k,.6),verbose=False,
                         minim_opts={"maxiter":1000,"gtol":1e-5})
    ret=res.optim_retvals
    diag={"success":bool(ret.success),"message":str(ret.message),"iterations":int(ret.nit),
          "gradient_norm":float(np.linalg.norm(ret.jac)),"warnings":" | ".join(str(w.message) for w in ws)}
    if not np.isfinite(res.params).all() or not np.isfinite(res.vcp_mean).all():
        raise RuntimeError("Nonfinite fit; analysis stops rather than dropping a replicate")
    if not ret.success:
        raise RuntimeError("Optimizer unsuccessful; analysis stops: "+str(ret.message))
    return res,diag

def observed_effect(fe,ranef):
    return float(100*np.mean(expit(fe[0]+fe[1]+ranef)-expit(fe[0]+ranef)))

def population_effect(fe,log_sd,nodes=80):
    # Sum of two independent Gaussian random intercepts is Gaussian.
    z,w=hermgauss(nodes);sd=np.sqrt(np.sum(np.exp(2*np.asarray(log_sd))))
    b=np.sqrt(2)*sd*z
    return float(100*np.dot(w,expit(fe[0]+fe[1]+b)-expit(fe[0]+b))/np.sqrt(np.pi))

def intervals(point,draws):
    out={}
    for method in ("percentile","basic"):
        ci={}
        for level,alpha in [(95,.025),(90,.05)]:
            lo,hi=np.quantile(draws,[alpha,1-alpha])
            if method=="basic":lo,hi=2*point-hi,2*point-lo
            ci[f"ci{level}_pp"]=[float(lo),float(hi)]
        a,z=ci["ci95_pp"];l,u=ci["ci90_pp"]
        # Threshold direction is pre-specified negative for H1; both directions
        # are exposed separately, never called a two-sided 5% magnitude test.
        ci["mechanical_rules_only"]={"nonzero_two_sided95":a>0 or z<0,"tost_equivalence_90":l>-10 and u<10,
                                     "negative_exceeds10_one_sided95":u < -10,
                                     "positive_exceeds10_one_sided95":l > 10}
        out[method]=ci
    return out

def run_job(job):
    name,scheme,draws,out=job
    rows,_,_=load_corrected();df=frame(name,rows);X,Z,ident=design(df)
    res,diag=fit(df.y,X,Z,ident);fe=res.fe_mean;ranef=np.asarray(Z@res.vc_mean).ravel()
    empirical=observed_effect(fe,ranef);population=population_effect(fe,res.vcp_mean)
    point=empirical if scheme=="observed" else population
    seed=SPECS[name]["seed"]+(100 if scheme=="population" else 0)
    rng=np.random.default_rng(seed);values=[];logs=[]
    for i in range(draws):
        b=ranef if scheme=="observed" else np.asarray(Z@(rng.normal(size=Z.shape[1])*np.exp(res.vcp_mean[ident]))).ravel()
        y=rng.binomial(1,expit(X@fe+b))
        # Same specified model and fixed starts on every replicate; no silent
        # replacement, omission, or treatment of numerical failure as success.
        fitstar,d=fit(y,X,Z,ident)
        est=observed_effect(fitstar.fe_mean,np.asarray(Z@fitstar.vc_mean).ravel()) if scheme=="observed" else population_effect(fitstar.fe_mean,fitstar.vcp_mean)
        values.append(est);logs.append({"replicate":i,"estimate_pp":est,**d})
    variance=np.exp(2*res.vcp_mean);total=float(variance.sum()+np.pi**2/3)
    info={"analysis":name,"role":SPECS[name]["role"],"scheme":scheme,
          "inference_status":"SENSITIVITY; post-analysis specification; independent methods review pending",
          "n":len(df),"n_condition0":int((df.x==0).sum()),"n_condition1":int((df.x==1).sum()),
          "values":int(df.value.nunique()),"models":int(df.model.nunique()),"point_pp":point,
          "raw_difference_pp":float(100*(df.loc[df.x==1,"y"].mean()-df.loc[df.x==0,"y"].mean())),
          "observed_cluster_point_pp":empirical,"population_integrated_point_pp":population,
          "quadrature_80_vs160_difference_pp":population-population_effect(fe,res.vcp_mean,160),
          "bootstrap_draws":draws,"seed":seed,"fit":diag,"fe_mean":fe.tolist(),"log_sd_mean":res.vcp_mean.tolist(),
          "variance_component_plug_in":variance.tolist(),
          "latent_scale_correlations":{"shared_value_only":float(variance[0]/total),"shared_model_only":float(variance[1]/total),"shared_both":float(variance.sum()/total)},
          "design_effect":"Not reported: no single equicorrelation design effect for crossed clusters and this nonlinear contrast.",
          "bootstrap_mean_pp":float(np.mean(values)),"bootstrap_displacement_pp":float(np.mean(values)-point),
          "intervals":intervals(point,values),"conditional_odds_ratio":float(np.exp(fe[1])),
          "conditional_or_vb95_credible":[float(np.exp(fe[1]-1.959964*res.fe_sd[1])),float(np.exp(fe[1]+1.959964*res.fe_sd[1]))]}
    dump_json(out/f"{name}_{scheme}.json",info);dump_csv(out/f"{name}_{scheme}_draws.csv",logs)
    return {"analysis":name,"scheme":scheme,"n":len(df),"point_pp":point,"draws":draws}
