"""Small nested-bootstrap diagnostic, NOT a certification of nominal coverage.

The generating parameter is known in this simulation. Conditional and population
targets each use their matching sampling ensemble. The study is post-analysis and
calibrated at one fitted parameter setting; results cannot validate all plausible
settings or choose an interval post hoc without an additional amendment.
"""
import os
for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","VECLIB_MAXIMUM_THREADS"):os.environ[key]="1"
import argparse
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from scipy.special import expit
from statsmodels.stats.proportion import proportion_confint
from data_pipeline import load_corrected,dump_json,dump_csv
from models import frame,design,fit,observed_effect,population_effect,intervals

def one(task):
    name,scheme,outer,inner=task
    rows,_,_=load_corrected();df=frame(name,rows);X,Z,ids=design(df)
    base,_=fit(df.y,X,Z,ids);rng=np.random.default_rng(830000+outer+(0 if scheme=="observed" else 10000))
    def simulate(res,redraw):
        b=rng.normal(size=Z.shape[1])*np.exp(res.vcp_mean[ids]) if redraw else res.vc_mean
        return rng.binomial(1,expit(X@res.fe_mean+np.asarray(Z@b).ravel()))
    def effect(res):
        return observed_effect(res.fe_mean,np.asarray(Z@res.vc_mean).ravel()) if scheme=="observed" else population_effect(res.fe_mean,res.vcp_mean)
    truth=effect(base);outerfit,_=fit(simulate(base,scheme=="population"),X,Z,ids)
    point=effect(outerfit);estimates=[]
    for i in range(inner):
        star,_=fit(simulate(outerfit,scheme=="population"),X,Z,ids);estimates.append(effect(star))
    result={"analysis":name,"scheme":scheme,"outer":outer,"inner":inner,"truth_pp":truth,"estimate_pp":point}
    for method,vals in intervals(point,estimates).items():
        for level in (90,95):
            low,high=vals[f"ci{level}_pp"]
            result[f"{method}_{level}_covers"]=bool(low<=truth<=high)
            result[f"{method}_{level}_width"]=high-low
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument("--out",type=Path,required=True)
    p.add_argument("--analysis",default="h1_arabic",choices=["h1_arabic","h2_joint"])
    p.add_argument("--outer",type=int,default=40);p.add_argument("--inner",type=int,default=99);p.add_argument("--workers",type=int,default=3)
    p.add_argument("--scheme",default="both",choices=["both","observed","population"])
    a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    schemes=("observed","population") if a.scheme=="both" else (a.scheme,)
    tasks=[(a.analysis,s,i,a.inner) for s in schemes for i in range(a.outer)]
    with ProcessPoolExecutor(max_workers=a.workers) as pool:records=list(pool.map(one,tasks))
    summary={"analysis":a.analysis,"outer_per_scheme":a.outer,"inner":a.inner,"status":"limited diagnostic; one fitted generating parameter; not release clearance", "coverage":{}}
    for scheme in schemes:
        rs=[r for r in records if r["scheme"]==scheme]
        for method in ("basic","percentile"):
            for level in (90,95):
                k=sum(r[f"{method}_{level}_covers"] for r in rs);lo,hi=proportion_confint(k,len(rs),method="wilson")
                summary["coverage"][f"{scheme}_{method}_{level}"]={"covered":k,"total":len(rs),"coverage":k/len(rs),"monte_carlo_wilson95":[float(lo),float(hi)]}
    dump_csv(a.out/f"calibration_{a.analysis}_trials.csv",records);dump_json(a.out/f"calibration_{a.analysis}.json",summary)
    print(summary,flush=True)

if __name__=="__main__":main()
