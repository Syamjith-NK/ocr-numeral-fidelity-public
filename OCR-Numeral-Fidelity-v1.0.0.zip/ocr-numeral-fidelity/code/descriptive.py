"""Corrected descriptives, paired H3 tests, and explicitly exploratory checks."""
import itertools
import numpy as np
from scipy.stats import binomtest
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.proportion import proportion_confint
from data_pipeline import dump_csv, dump_json
from scoring import CATEGORIES

def diff(rows, outcome, group):
    a = [r[outcome] for r in rows if group(r)]
    b = [r[outcome] for r in rows if not group(r)]
    return None if not a or not b else 100*(np.mean(a)-np.mean(b))

def paired_value_boot(rows, outcome, group, seed, draws=2000):
    """One resample includes all observations of a drawn value, retaining pairing."""
    values = sorted({r["value"] for r in rows}); arrays = []
    for value in values:
        rs = [r for r in rows if r["value"]==value]
        a = [r[outcome] for r in rs if group(r)]; b = [r[outcome] for r in rs if not group(r)]
        arrays.append([sum(a),len(a),sum(b),len(b)])
    cells=np.array(arrays); rng=np.random.default_rng(seed)
    sampled=cells[rng.integers(0,len(values),size=(draws,len(values)))].sum(axis=1)
    valid=(sampled[:,1]>0)&(sampled[:,3]>0)
    d=100*(sampled[valid,0]/sampled[valid,1]-sampled[valid,2]/sampled[valid,3])
    return {"point_pp":diff(rows,outcome,group),"ci95_percentile_pp":np.quantile(d,[.025,.975]).tolist(),
            "ci90_percentile_pp":np.quantile(d,[.05,.95]).tolist(),"valid_draws":int(valid.sum()),
            "attempted_draws":draws,"seed":seed,"status":"exploratory; value-resampling population"}

def run(rows,out):
    core=[r for r in rows if r["arm"]=="core" and r["retained"]]
    nw=[r for r in core if r["system"]!="western"]
    neutral=[r for r in nw if r["prompt"]=="neutral"]
    cats=[];rates=[]
    for prompt in ["neutral","preserve"]:
        rs=[r for r in nw if r["prompt"]==prompt]
        for cat in CATEGORIES:
            cats.append({"prompt":prompt,"category":cat,"count":sum(r["category"]==cat for r in rs),"n":len(rs)})
        for name,key,den in [("value","value_correct",rs),("joint","joint_correct",rs),
                              ("script_fidelity","script_preserved",[r for r in rs if r["emits_digit"]])]:
            k=sum(r[key] for r in den)
            rates.append({"prompt":prompt,"outcome":name,"successes":k,"denominator":len(den),"rate_pct":100*k/len(den)})
    dump_csv(out/"categories.csv",cats);dump_csv(out/"prompt_rates.csv",rates)
    ar=[r for r in neutral if r["system"]=="arabic"]
    per=[];by={}
    for m in sorted({r["model"] for r in ar}):
        rs=[r for r in ar if r["model"]==m];by[m]={r["value"]:r["joint_correct"] for r in rs}
        k=sum(r["joint_correct"] for r in rs);n=len(rs);lo,hi=proportion_confint(k,n,method="wilson")
        per.append({"model":m,"joint_correct":k,"n":n,"value_correct":sum(r["value_correct"] for r in rs),
                    "wilson95_low_pct":100*lo,"wilson95_high_pct":100*hi})
    pairs=[]
    for a,b in itertools.combinations(sorted(by),2):
        assert set(by[a])==set(by[b])
        ab=sum(by[a][v] and not by[b][v] for v in by[a]);ba=sum(by[b][v] and not by[a][v] for v in by[a])
        p=binomtest(ab,ab+ba,.5).pvalue if ab+ba else 1.
        pairs.append({"model_a":a,"model_b":b,"n_paired":len(by[a]),"a_only_correct":ab,"b_only_correct":ba,
                      "difference_a_minus_b_pp":100*(ab-ba)/len(by[a]),"p_exact_mcnemar":p})
    for row,p in zip(pairs,multipletests([r["p_exact_mcnemar"] for r in pairs],method="holm")[1]):
        row.update(p_holm=float(p),reject_05=bool(p<.05))
    dump_csv(out/"h3_model_rates.csv",per);dump_csv(out/"h3_paired_holm.csv",pairs)
    strata=[]
    for st in ["short","medium","long"]:
        rs=[r for r in neutral if r["stratum"]==st]
        strata.append({"stratum":st,"n":len(rs),"value_correct":sum(r["value_correct"] for r in rs),
                       "joint_correct":sum(r["joint_correct"] for r in rs)})
    dump_csv(out/"strata.csv",strata)
    robust=[]
    for font,size in sorted({(r["font"],r["size"]) for r in rows if r["arm"]=="robust"}):
        rs=[r for r in rows if r["arm"]=="robust" and r["font"]==font and r["size"]==size]
        elig=[r for r in rs if r["retained"] and r["system"]!="western" and r["category"] in CATEGORIES[:2]]
        robust.append({"font":font,"size":size,"total_trials":len(rs),"excluded_trials":sum(not r["retained"] for r in rs),
                       "h1_eligible":len(elig),"raw_converted_minus_preserved_pp":diff(elig,"value_correct",lambda r:r["category"]=="B_all_western"),
                       "strata":";".join(sorted({r["stratum"] for r in rs}))})
    dump_csv(out/"robustness_descriptive.csv",robust)
    exploratory={"empty_outputs":paired_value_boot([{**r,"empty":not r["emits_digit"]} for r in nw],"empty",lambda r:r["prompt"]=="preserve",202610081),
                 "h2_raw_joint":paired_value_boot(nw,"joint_correct",lambda r:r["prompt"]=="preserve",202610082),"per_model_h1":{}}
    for i,m in enumerate(sorted({r["model"] for r in neutral})):
        rs=[r for r in neutral if r["model"]==m and r["category"] in CATEGORIES[:2]]
        counts={c:sum(r["category"]==c for r in rs) for c in CATEGORIES[:2]}
        obj={"counts":counts,"raw_converted_minus_preserved_pp":diff(rs,"value_correct",lambda r:r["category"]=="B_all_western")}
        if min(counts.values())>=10:
            obj["exploratory_interval"]=paired_value_boot(rs,"value_correct",lambda r:r["category"]=="B_all_western",202610090+i)
        else:obj["interval_status"]="Not computed: sparse or absent comparison arm (<10); no reversal claim."
        exploratory["per_model_h1"][m]=obj
    dump_json(out/"exploratory.json",exploratory)
