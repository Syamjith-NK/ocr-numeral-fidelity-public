"""Recheck warning-bearing bootstrap fits with a second optimizer.

This is a numerical sensitivity diagnostic, not an independent implementation
or statistical validation. Original warning records and estimates are retained.
"""
import os
for key in ("OPENBLAS_NUM_THREADS","OMP_NUM_THREADS","VECLIB_MAXIMUM_THREADS"):os.environ[key]="1"
import csv,json,warnings
from pathlib import Path
import numpy as np
from scipy.special import expit
from statsmodels.genmod.bayes_mixed_glm import BinomialBayesMixedGLM
from data_pipeline import ROOT,load_corrected,dump_json,dump_csv
from models import SPECS,frame,design,fit,observed_effect,population_effect

def main():
    directory=ROOT/'results/full';all_rows,_,_=load_corrected();checks=[]
    for path in sorted(directory.glob('*_draws.csv')):
        name,scheme=path.stem.removesuffix('_draws').rsplit('_',1)
        with path.open() as f:records=list(csv.DictReader(f))
        targets={int(r['replicate']):r for r in records if r['warnings']}
        if not targets:continue
        df=frame(name,all_rows);X,Z,ids=design(df);base,_=fit(df.y,X,Z,ids)
        observed=np.asarray(Z@base.vc_mean).ravel();rng=np.random.default_rng(SPECS[name]['seed']+(100 if scheme=='population' else 0))
        for i in range(max(targets)+1):
            b=observed if scheme=='observed' else np.asarray(Z@(rng.normal(size=Z.shape[1])*np.exp(base.vcp_mean[ids]))).ravel()
            y=rng.binomial(1,expit(X@base.fe_mean+b))
            if i not in targets:continue
            m=BinomialBayesMixedGLM(y,X,Z,ids,vcp_p=1.,fe_p=2.);k=m.k_fep+m.k_vcp+m.k_vc
            with warnings.catch_warnings(record=True) as ws:
                warnings.simplefilter('always')
                alt=m.fit_vb(mean=np.zeros(k),sd=np.full(k,.6),fit_method='L-BFGS-B',
                             minim_opts={'maxiter':3000,'gtol':1e-6,'ftol':1e-12})
            estimate=observed_effect(alt.fe_mean,np.asarray(Z@alt.vc_mean).ravel()) if scheme=='observed' else population_effect(alt.fe_mean,alt.vcp_mean)
            finite=bool(all(np.isfinite(x).all() for x in [alt.params,alt.fe_sd,alt.vc_sd,alt.vcp_sd,alt.optim_retvals.jac]))
            checks.append({'analysis':name,'scheme':scheme,'replicate':i,'original_estimate_pp':float(targets[i]['estimate_pp']),
                           'alternative_estimate_pp':estimate,'difference_pp':estimate-float(targets[i]['estimate_pp']),
                           'alternative_success':bool(alt.optim_retvals.success),'alternative_finite':finite,
                           'alternative_gradient_norm':float(np.linalg.norm(alt.optim_retvals.jac)),
                           'alternative_warnings':' | '.join(str(w.message) for w in ws)})
    summary={'scope':'Every full-run replicate whose original optimizer emitted any warning',
             'n_warning_fits':len(checks),'all_alternative_success':all(r['alternative_success'] for r in checks),
             'all_alternative_finite':all(r['alternative_finite'] for r in checks),
             'max_absolute_effect_difference_pp':max([abs(r['difference_pp']) for r in checks],default=0),
             'status':'Numerical sensitivity only; warnings retained and no inference method certified.'}
    if checks:dump_csv(ROOT/'results/warning_refits.csv',checks)
    dump_json(ROOT/'results/warning_refits_summary.json',summary);print(summary,flush=True)

if __name__=='__main__':main()
