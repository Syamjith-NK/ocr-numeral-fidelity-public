"""Read immutable raw outputs; derive corrected scores and control exclusions."""
from pathlib import Path
import csv
import hashlib
import json
from scoring import score

ROOT = Path(__file__).resolve().parents[1]
KEYS = ("model", "arm", "font", "size", "prompt", "value", "system")

def trial_id(row):
    return "|".join(str(row[k]) for k in KEYS)

def load_corrected():
    rows, changes, gates = [], [], []
    seen = set()
    for path in sorted((ROOT / "raw").glob("confirm_*.json")):
        source = json.loads(path.read_text())
        file_rows = []
        for old in source["rows"]:
            key = trial_id(old)
            if key in seen:
                raise ValueError("Duplicate trial: " + key)
            seen.add(key)
            row = dict(old)
            new = score(row["system"], row["raw_output"], row["value"])
            modified = {k: {"old": old[k], "new": v} for k,v in new.items()
                        if k in old and old[k] != v}
            if modified:
                changes.append({"source": "raw/"+path.name, "trial_id": key,
                                "raw_output": row["raw_output"], "changes": modified})
            row.update(new)
            row["trial_id"] = key
            file_rows.append(row)
        for font in sorted({r["font"] for r in file_rows}):
            controls = [r for r in file_rows if r["font"] == font and r["system"] == "western"]
            n = len(controls); k = sum(r["value_correct"] for r in controls)
            passes = n > 0 and k/n >= .9
            original = source["western_control"][font]
            if (k,n,passes) != (original["correct"],original["n"],original["passes_90pct"]):
                raise ValueError("Control gate no longer matches original record")
            gates.append({"arm": source["arm"], "model": source["model"], "font": font,
                          "correct": k, "n": n, "passes": passes})
            for r in file_rows:
                if r["font"] == font:
                    r["retained"] = passes
        rows.extend(file_rows)
    if len(rows) != 7000:
        raise ValueError(f"Expected 7000 raw trials, found {len(rows)}")
    return rows, changes, gates

def dump_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, allow_nan=False)+"\n")

def dump_csv(path, rows):
    rows = list(rows); path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        raise ValueError("Refusing ambiguous empty CSV: " + str(path))
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0])); writer.writeheader(); writer.writerows(rows)

def write_rescoring(out):
    rows, changes, gates = load_corrected()
    dump_json(out/"scoring_changes.json", changes)
    dump_csv(out/"control_gates.csv", gates)
    with (out/"corrected_trials.jsonl").open("w") as f:
        for r in rows:
            f.write(json.dumps(r,ensure_ascii=False)+"\n")
    dump_json(out/"raw_provenance.json", {"raw/"+p.name: hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted((ROOT/"raw").glob("*.json"))})
    return rows
