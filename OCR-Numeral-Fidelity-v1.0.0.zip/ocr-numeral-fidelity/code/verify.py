"""Verify release bytes and substantive facts, without running model evaluation."""
from pathlib import Path
import argparse,hashlib,json,csv
import numpy as np
from scipy.stats import binomtest
from statsmodels.stats.multitest import multipletests
from data_pipeline import ROOT,load_corrected
from scoring import score

def verify_results(folder):
    paths=sorted(folder.glob("h*_observed.json"))+sorted(folder.glob("h*_population.json"))
    assert len(paths)==10, f"Expected ten complete model summaries, found {len(paths)}"
    for p in paths:
        d=json.loads(p.read_text());draw_path=p.with_name(p.stem+"_draws.csv")
        with draw_path.open() as f:draws=list(csv.DictReader(f))
        assert len(draws)==d["bootstrap_draws"]==2000,(p.name,"draw count")
        assert d["fit"]["success"] and all(x["success"]=="True" for x in draws),(p.name,"optimizer status")
        arr=np.array([float(x["estimate_pp"]) for x in draws]);assert np.isfinite(arr).all()
        for method in ["basic","percentile"]:
            for level,a in [(95,.025),(90,.05)]:
                q=np.quantile(arr,[a,1-a]);expected=q if method=="percentile" else 2*d["point_pp"]-q[::-1]
                np.testing.assert_allclose(expected,d["intervals"][method][f"ci{level}_pp"],rtol=0,atol=1e-10)
            v=d["intervals"][method];lo,hi=v["ci95_pp"];a,b=v["ci90_pp"]
            assert v["mechanical_rules_only"]=={"nonzero_two_sided95":lo>0 or hi<0,"tost_equivalence_90":a>-10 and b<10,
                    "negative_exceeds10_one_sided95":b< -10,"positive_exceeds10_one_sided95":a>10}
        assert abs(d["quadrature_80_vs160_difference_pp"])<.01,(p.name,"quadrature")
    rows,changes,gates=load_corrected();assert len(changes)==22
    assert len(rows)==7000 and sum(r["retained"] for r in rows)==6000
    with (folder/"corrected_trials.jsonl").open() as f:stored=[json.loads(line) for line in f]
    assert stored==rows,"Derived trial file does not equal fresh rescoring"
    with (folder/"h3_paired_holm.csv").open() as f:pairs=list(csv.DictReader(f))
    assert len(pairs)==10
    pvalues=[]
    ar=[r for r in rows if r["arm"]=="core" and r["system"]=="arabic" and r["prompt"]=="neutral" and r["retained"]]
    for row in pairs:
        aa={r["value"]:r["joint_correct"] for r in ar if r["model"]==row["model_a"]}
        bb={r["value"]:r["joint_correct"] for r in ar if r["model"]==row["model_b"]}
        assert set(aa)==set(bb) and len(aa)==100
        ab=sum(aa[v] and not bb[v] for v in aa);ba=sum(bb[v] and not aa[v] for v in aa)
        assert (ab,ba)==(int(row["a_only_correct"]),int(row["b_only_correct"]))
        pv=binomtest(ab,ab+ba,.5).pvalue if ab+ba else 1.;pvalues.append(pv)
        assert abs(pv-float(row["p_exact_mcnemar"]))<1e-12
    np.testing.assert_allclose(multipletests(pvalues,method="holm")[1],[float(x["p_holm"]) for x in pairs],rtol=0,atol=1e-12)
    with (folder/"prompt_rates.csv").open() as f:rates=list(csv.DictReader(f))
    for row in rates:
        rs=[r for r in rows if r["arm"]=="core" and r["retained"] and r["system"]!="western" and r["prompt"]==row["prompt"]]
        key={"joint":"joint_correct","value":"value_correct","script_fidelity":"script_preserved"}[row["outcome"]]
        if row["outcome"]=="script_fidelity":rs=[r for r in rs if r["emits_digit"]]
        assert len(rs)==int(row["denominator"]) and sum(r[key] for r in rs)==int(row["successes"])
    print("Scientific checks PASS: fresh rescoring of 7,000 trials, control gates, H3 pairing/Holm, denominators, 20,000 draws, optimizer flags and interval/decision arithmetic.")

def main():
    parser=argparse.ArgumentParser();parser.add_argument("--results",type=Path,default=ROOT/"results/full");parser.add_argument("--skip-manifest",action="store_true");a=parser.parse_args()
    if not a.skip_manifest:
        entries={}
        for line in (ROOT/"MANIFEST.sha256").read_text().splitlines():
            if not line or line.startswith("#"):continue
            digest,name=line.split("  ",1)
            assert name not in entries,"Duplicate manifest entry"
            target=(ROOT/name).resolve();assert target.is_relative_to(ROOT.resolve()),"Unsafe manifest path"
            assert hashlib.sha256(target.read_bytes()).hexdigest()==digest,name
            entries[name]=digest
        actual={str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.relative_to(ROOT).parts and "__pycache__" not in p.parts and not p.name.endswith(".pyc")}
        assert actual==set(entries)|{"MANIFEST.sha256"},actual.symmetric_difference(set(entries)|{"MANIFEST.sha256"})
        print(f"Manifest PASS: {len(entries)} files; no missing or unlisted payloads.")
    verify_results(a.results)

if __name__=="__main__":main()
