# Correction 4 — the rebuilt estimator was not the protocol's estimator

Found by external review of the released code, not by rerunning it. Reproducing a
number proves a script is deterministic; it does not prove the script implements what
was pre-registered. Three departures from §5b, all now fixed.

## 1. It was not g-computation

§5b: *predict each observation under both conditions, average the predictions within
condition, take the difference.*

The previous `fit_gcomp` zeroed the random effects and evaluated a single logistic
curve at the fixed effects, while its own docstring claimed to be doing the averaging.
**The comment defending it — "random effects average to zero in the marginal
prediction" — is false for a logistic model.** The mean of predicted probabilities is
not the probability at the mean, because the inverse logit is nonlinear. Jensen's
inequality, not a rounding difference.

`gcomputation()` now carries each observation's own random effects through both
predictions and averages over observations.

## 2. The interval was the wrong bootstrap

§5b fixes a **parametric** bootstrap over the fitted model with **2,000** draws. The
code ran a **nonparametric cluster** bootstrap with **300**, and that deviation was
never declared. It now redraws the cluster-level random effects from their fitted
distribution, simulates outcomes, refits, and recomputes, 2,000 times.

## 3. "Converged" claimed a check that was never made

`BinomialBayesMixedGLM.fit_vb` is variational Bayes and reports no convergence status.
The counter only caught replicates that raised. The output now says **completed**.

## Effect on the result

| | before (non-compliant) | now (§5b) |
|---|---|---|
| adjusted marginal difference | −12.0 pp | **−12.8 pp** |
| 95% CI | [−20.9, −5.5] | **[−27.5, −5.4]** |
| 90% TOST interval | [−19.5, −6.3] | **[−25.7, −6.7]** |
| bootstrap | 300 nonparametric | **2,000 parametric** |
| non-zero association | supported | supported |
| equivalence within ±10pp | not established | not established |
| exceeds ±10pp | not established | not established |

**All three verdicts are unchanged.** The point estimate moves by 0.8 points.

⚠️ An earlier version of this file claimed the interval "widened, the conservative
direction" and cited an independent reimplementation agreeing at −12.8. Both were
withdrawn: the upper bound barely moved, and the second implementation is not in this
archive so no reader can check it. See CORRECTION_5.

## Also recorded

The model random effect has only five levels, so that variance component is weakly
identified. Now stated in the paper's limitations rather than left implicit.
