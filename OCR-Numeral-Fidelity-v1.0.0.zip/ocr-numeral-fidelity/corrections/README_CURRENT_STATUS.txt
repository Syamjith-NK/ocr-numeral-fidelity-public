Historical correction narratives are superseded by docs/CORRECTION_6.txt and the statistical amendments in protocol/. They are retained as scientific provenance, not active results or instructions.
