# Correction 5 — the bootstrap and the estimate were measuring different things

Found by external review, which ran the released code and then checked what the
bootstrap was actually doing rather than only whether it reproduced.

## The defect

§5b defines the estimand as the marginal risk difference averaged **over the observed
distribution of test values and models**. `gcomputation()` did that. The bootstrap did
not: it redrew fresh cluster-level random effects in every replicate, so each replicate
targeted a *different* population quantity. The estimate described the clusters we have;
the interval described clusters we do not.

The symptom was visible and we had not looked for it: **the replicates did not centre on
the point estimate.**

## Fix, and a second finding underneath it

The bootstrap now holds the observed clusters' fitted random effects fixed and simulates
only the outcomes, so estimate and interval describe the same quantity.

That removed the estimand mismatch but **did not remove the off-centring**: replicates
centre about 3.2 points below the point estimate, because refitting simulated data
re-shrinks the random effects. With a biased bootstrap distribution the interval type
stops being cosmetic, and §5b fixed the bootstrap without fixing the interval type.

We report the **basic (reverse-percentile) interval**, which corrects for exactly this
bias, and the percentile interval as a sensitivity check.

| 95% interval | result | "exceeds ±10pp" |
|---|---|---|
| **basic (primary)** | **[−15.9, −2.0]** | **not established** |
| percentile (sensitivity) | [−23.5, −9.7] | supported |

**Stated plainly because it cuts against us: the percentile interval would support the
stronger claim.** We do not make it. The percentile interval assumes the bootstrap
distribution is centred on the estimate, and we can see that it is not.

## Effect on the result

| | before | now |
|---|---|---|
| adjusted marginal difference | −12.8 pp | −12.8 pp (unchanged) |
| 95% CI | [−27.5, −5.4] | **[−15.9, −2.0]** |
| 90% TOST interval | [−25.7, −6.7] | **[−15.0, −3.3]** |
| non-zero association | supported | supported |
| equivalence within ±10pp | not established | not established |
| exceeds ±10pp | not established | not established |

All three verdicts unchanged, now resting on an interval that measures the same thing
the estimate does.

## Two claims withdrawn

1. **"The interval widened, the conservative direction."** Wrong as stated. The lower
   bound moved a long way but the upper bound, which decides the association verdict,
   barely moved (−5.5 to −5.4). Removed.
2. **"An independent reimplementation produced −12.8 as well."** That second
   implementation is not in this archive and cannot be checked by a reader, so the claim
   has been removed from `CORRECTION_4` rather than left as something to be taken on
   trust.
