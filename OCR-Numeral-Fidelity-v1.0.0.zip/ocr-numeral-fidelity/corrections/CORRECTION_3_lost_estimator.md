# Correction 3 — the §5b estimator was rebuilt, and the interval moved

## What happened

The paper's primary H1 result is the **adjusted** marginal risk difference specified in
§5b of the frozen protocol: a mixed-effects logistic model with random intercepts for
test value and model, the marginal effect by g-computation, intervalled by a cluster
bootstrap that refits the model in each replicate.

`analyse.py` does **not** implement that. It computes a *raw* marginal difference with a
cluster bootstrap, which is **−28.6 pp**. The adjusted figure was originally produced by
a separate one-off that was never saved. The released bundle therefore did not reproduce
the paper's headline, and a reviewer running `analyse.py` would have obtained −28.6 pp
and the **opposite** verdict on the 10-point bound.

This was found by extracting the released archive into a clean directory and running it
the way a reviewer would, rather than by re-reading the code.

## What changed

`code/adjusted.py` is the §5b estimator, rebuilt from the protocol text.

| quantity | originally published | released code produces |
|---|---|---|
| adjusted marginal difference | −12.0 pp | **−12.0 pp** |
| 95% CI | [−17.9, −3.7] | **[−20.9, −5.5]** |
| non-zero association | supported | supported |
| equivalence within ±10pp | not established | not established |
| exceeds ±10pp | not established | not established |

The point estimate reproduces exactly and **all three verdicts are unchanged**. The
interval is wider, which is the conservative direction: it weakens no claim. The paper
now reports the interval this code produces, because a number that the released code
cannot reproduce has no business being the number of record.

## A bug found while rebuilding it, worth stating

The first rebuild returned [−29.9, −11.9] — an interval whose upper edge nearly touched
the point estimate. That asymmetry was the signal. The cluster-resampling step assigned
a new cluster id per **row** rather than per **draw**, so every observation became its
own cluster, the random intercept collapsed, and the interval drifted toward the raw
contrast. A value drawn twice must appear as two distinct clusters with all of that
draw's rows sharing one id. Fixed in `adjusted.py`, which carries the explanation inline.

## Still true, and independently checked

ICC 0.279 and design effect 3.17 reproduce exactly from `analyse.py`, as printed in the
paper.

## Certified from a clean extraction, 2026-10-08

Run end to end from a fresh unzip of the submitted archive, with nothing copied and
the documented command used verbatim (`python code/adjusted.py` from the archive root):

```
rows 862   preserved 113   converted 749   values 98   models 5
raw (unadjusted) difference : -28.6 pp
ADJUSTED marginal difference: -12.0 pp
bootstrap: 300 of 300 replicates converged (0 non-convergent)
95% CI [-20.9, -5.5]
90% CI [-19.5, -6.3]   (the TOST interval)
  non-zero association : supported
  equivalence +/-10pp  : not established
  exceeds +/-10pp      : not established
```

Identical across three independent runs; the estimator is seeded. **Both intervals are
preserved in this record on purpose**: `[-17.9, -3.7]` is what was originally published
in rev7 from the lost implementation, `[-20.9, -5.5]` is what the released code
produces and what the manuscript now reports.

## A second path defect found at the same time

The documented command did not work. `analyse.py` globbed relative to its own directory
(`code/`) and `adjusted.py` relative to the working directory, while the raw trials live
in `raw/`. From the archive root `python code/analyse.py` printed **"no confirmatory
data yet"** -- an empty result that reads as "no data" rather than "broken path". My own
reviewer simulation had masked it by copying the raw files first. Both scripts now
resolve `raw/` themselves and work from the archive root, from inside `code/`, and from
an unpacked copy elsewhere.

## Clean-room reproduction, 2026-10-08

Re-run on a different interpreter from the one used for development, in a virtual
environment built from nothing, installing only the declared analysis requirements:

```
python3 -m venv .venv
.venv/bin/pip install -r requirements-analysis.txt   # numpy, pandas, statsmodels
.venv/bin/python code/adjusted.py
```

Confirmed absent from that environment before installing: numpy, pandas, statsmodels,
torch. Confirmed still absent after: torch. The analysis path imports no deep-learning
stack and downloads no weights.

Output was identical to the development run: **-12.0 pp, 95% CI [-20.9, -5.5], 90% CI
[-19.5, -6.3], 300/300 replicates converged**, all three verdicts unchanged. Four
independent runs now agree; the estimator is seeded.

---

⚠️ **SUPERSEDED IN PART by `CORRECTION_4_protocol_compliance.md`.** The rebuild
described above reproduced deterministically but did not implement §5b: it was not
g-computation, and it used a 300-draw nonparametric bootstrap where the protocol fixes
a 2,000-draw parametric one. The figures quoted in this file (−12.0 pp,
[−20.9, −5.5]) are therefore the *non-compliant* rebuild. The compliant result is
−12.8 pp, [−27.5, −5.4]. All three verdicts are the same in both. This file is kept
unedited as the record of what was believed at the time.
