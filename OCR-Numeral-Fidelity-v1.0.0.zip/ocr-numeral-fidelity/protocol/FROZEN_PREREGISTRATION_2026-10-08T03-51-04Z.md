# Pre-registration — confirmatory study of numeral fidelity in OCR systems

**Written 2026-10-08, BEFORE any confirmatory data collection.**
Frozen on first run. Any change after that date is an amendment, dated and
stated, not a silent edit.

⛔ **The 360-condition pilot (`matched_*.json`, `gemini_result.json`) is NOT part
of this study.** It generated the hypotheses below and is reported separately as
exploratory. It will not be pooled, and no pilot value is reused as a test item.

---

## 1. Primary hypothesis, fixed in advance

**H1 (primary).** In released OCR systems, outputs that convert non-Western
numerals to Western digits have **lower value accuracy** than outputs that
preserve the source script. Script conversion and numerical corruption are
associated, not independent.

**Primary outcome measure.** The within-model difference in value accuracy
between script-preserved and script-converted outputs, on Arabic-Indic input,
neutral prompt, pooled across models with a random intercept per test value.

**Pilot estimate to be confirmed or refuted:** 67% vs 17% (n=58 vs 159).

⚠️ **Known limitation of H1, stated now rather than discovered later.** Script
category is an OUTPUT, not a manipulated factor, so this is an observational
association within outputs and conditioning on it can induce selection effects.
H1 therefore cannot support a causal claim, and will not be worded as one. H2 is
the manipulated counterpart.

**H2 (primary, manipulated).** Explicitly instructing a model to preserve the
numeral script raises **JOINT value-and-script accuracy** relative to a neutral
transcription instruction. This is the only true experimental manipulation in
the design and is the test of whether conversion is *steerable* — which bears
directly on whether it is deliberate behaviour.

🔑 **H2's primary outcome is JOINT accuracy, not script fidelity.** Fixed in
advance because preserving the script while corrupting the number is not a
practical improvement — a model that obeys the instruction and returns the wrong
value has not been improved, it has been made confidently wrong in the right
alphabet. Script fidelity alone and value accuracy alone are reported as
secondary outcomes so the mechanism is visible, but H2 succeeds or fails on the
joint measure.

**H3 (secondary).** Joint accuracy (value AND script both correct) differs
between released systems by more than sampling error.

**The 10pp thresholds are PRACTICAL-significance bounds, not hypothesis tests.**
A difference under 10pp does NOT establish that an effect is absent. To claim
absence rather than merely "not detected", an **equivalence test (TOST)** is
pre-specified with bounds of ±10pp on the difference in proportions: equivalence
is concluded only if the 90% CI for the difference lies entirely within ±10pp.
Three outcomes are therefore possible and all are reportable: **effect present**
(CI excludes 0 and exceeds the bound), **equivalent** (CI inside ±10pp), and
**inconclusive** (CI spans both) — the third being a genuine possibility that
will be reported as such rather than rounded to one of the others.

**Pre-specified null results worth reporting.** A demonstrated equivalence on H1
or H2 is a publishable negative finding. No reframing to find a positive.

---

## 2. Stimuli

**Test values — 100 per script, newly generated, independent of the pilot.**
- Drawn from a seeded RNG (`seed=20261008`), recorded in `values.json` before
  first use.
- **Three length strata**, balanced: short (1-2 digits), medium (3-4), long
  (5-6). Six digits is the upper bound.
- ⚠️ **Accuracy is reported separately by stratum.** Long strings test
  segmentation as much as numeral identity, so a six-digit failure must NOT be
  cited as glyph confusion without character-level analysis showing which
  position failed.
- Balanced for **digit frequency** (each of 0-9 appears comparably often across
  the set), **repeated digits**, and **visually confusable combinations**
  (notably those containing `٠`/`۰` against `٥`, and `٦` against `٧`).
- Constrained so each stratum contains: values with ≥1 zero, values with no
  zero, values with repeated digits, and values with all digits distinct.
  Zero matters because `٠` is the pilot's worst character.
- ⛔ None of the pilot's five values (2026, 1445, 7, 350, 1990) may appear.

**Scripts — 4, fully crossed with values:** Western (U+0030, control),
Arabic-Indic (U+0660), Extended Arabic-Indic / Persian (U+06F0), Devanagari
(U+0966). The SAME 100 values are rendered in all four, so script is a
within-value factor.

**Rendering.** Pillow, black on white, centred, generous margin. Per-script font
list fixed in advance. Western control rendered in the **same typeface and point
size** as the script it is compared against — this is the design's core control
and is non-negotiable.

---

## 3. Design

**Core confirmatory arm** (powers H1, H2, H3):
100 values × 4 scripts × 2 prompts × 6 models, at ONE typeface (Arial Unicode)
and ONE size (72px) = **800 trials per model, 4,800 total.**

**Robustness arm** (typeface/size generalisation, neutral prompt only):
a fixed 25-value subset × 4 scripts × 3 typefaces × 2 sizes × 6 models =
**600 per model, 3,600 total.**

Balanced: every value appears in every script; every model sees every stimulus.

**Prompt conditions, fixed verbatim now:**
- `neutral` — "Extract the text from this image exactly as written. Output only
  the text."  *(identical to the pilot, so the pilot remains interpretable
  alongside though not pooled)*
- `preserve` — "Extract the text from this image exactly as written, keeping the
  original numeral characters unchanged. Output only the text."

**Models — 6, fixed:** Qari-OCR v0.3 · Qwen2-VL-2B-Instruct · Qwen2.5-VL-3B-
Instruct · sherif1313 Arabic-English-handwritten-OCR-v3 · bakrianoo
arabic-legal-documents-ocr-1.0 · Gemini 3 Flash.
✅ **The bakrianoo Gemma specialist is included regardless of whether the gated
Gemma base clears.** A reliability audit of released systems does not require
the base checkpoint; only a base-vs-finetune causal claim would, and no such
claim is being made. `google/gemma-3-4b-it` is added only if access clears.

**Three comparison classes, kept distinct and never merged:**
1. Qwen specialists vs available base-family models — *base-family*, not
   parent-verified (Qari declares no base).
2. The Gemma specialist as an **independent architecture** — no base available.
3. Gemini as a **frontier reference point** — not a peer of either group.
⛔ No base-versus-fine-tune causal claim is licensed by any of these.

---

## 4. Frozen procedure

- **Decoding:** greedy (`do_sample=False`), `max_new_tokens=32`.
- **dtype:** bfloat16 on MPS for all local models (fp16 produced NaN padding for
  Gemma in the pilot); recorded per run.
- **Gemini:** temperature 0, model string and date recorded; a 5% random subset
  re-run to measure API determinism rather than assume it.
- **Preprocessing:** none beyond rendering. No deskew, no binarisation.
- **Call budget:** hard cap, abort rather than overrun.

## 5. Scoring, fixed before testing

- **value accuracy** — digits extracted, each normalised via
  `unicodedata.decimal`, compared to intent. Denominator = all trials.
- **script fidelity** — all emitted digits belong to the input's Unicode block.
  Denominator = trials emitting ≥1 digit. Reported with that denominator stated.
- **joint accuracy** — value AND script correct. Denominator = all trials.
  **This is the practitioner-facing number.**
- **Error categories**, mutually exclusive and exhaustive:
  A preserved · B all-Western · C mixed input+Western · D third-script
  substitution · E no digit emitted.

**Exclusions, fixed now:** a model×typeface cell whose **Western control is
below 90%** is reported as a control failure and excluded from H1–H3, with the
raw outputs retained and shown. No other exclusions permitted.

## 5b. ESTIMAND — fixed, because the model and the test must agree

⚠️ A mixed-effects logistic regression estimates a **conditional** (cluster-
specific) odds ratio. The ±10pp TOST bound is a **marginal risk difference**.
These are different quantities and are NOT interchangeable — a conditional OR
cannot be compared against a marginal pp bound without transformation.

**The primary estimand for H1 and H2 is the MARGINAL RISK DIFFERENCE in
percentage points**, population-averaged over the observed distribution of test
values and models.

Procedure, fixed now:
1. Fit the mixed-effects logistic model (random intercepts for test value and
   model) — it handles the clustering.
2. Obtain the marginal effect by **g-computation / average marginal effects**:
   predict each observation under both conditions, average the predictions
   within condition, take the difference.
3. Interval by **parametric bootstrap over the fitted model** (2,000 draws),
   resampling at the cluster level so the clustering is carried into the
   interval.
4. **TOST is applied to that same bootstrapped marginal difference**, 90% CI
   against ±10pp. Model, estimate and equivalence test therefore refer to one
   quantity throughout.

Conditional odds ratios may be reported as a secondary descriptive, explicitly
labelled conditional, and are never compared against the pp bounds.

## 6. Analysis, pre-specified

- **Primary (H1):** mixed-effects logistic regression, value-correct ~
  script_converted + (1|test_value) + (1|model). Report odds ratio with 95% CI.

⚠️ **100 values per cell is NOT 100 independent observations.** The same values
recur across scripts, prompts, typefaces and models, so trials are clustered and
the effective sample size is smaller than the nominal one — by a factor of
roughly 1+(m-1)·ICC. All intervals come from the mixed model, never from a naive
Wilson calculation on pooled trials, and the **intra-class correlation and the
implied design effect are reported** so a reader can see the real precision. If
the ICC proves high, the honest conclusion may be that even 100 values are
underpowered, and that will be stated rather than hidden behind a nominal n.
- **H2:** same structure on the PRIMARY outcome, joint_correct ~ prompt +
  (1|value) + (1|model). Script fidelity and value accuracy are modelled
  identically as pre-specified secondary outcomes.
- **H3:** per-model joint accuracy with Wilson 95% CIs; pairwise comparisons
  **Holm-corrected** across the 15 model pairs.
- **Effect sizes** reported throughout, not only significance.
- ⛔ **No comparison not listed here will be reported as confirmatory.** Anything
  else is exploratory and labelled so.

## 7. What would falsify the central claim

If script-converted outputs show value accuracy within 10pp of script-preserved
outputs, H1 is refuted and the paper's central argument — that conversion to
Western digits is not a benign re-encoding — does not hold. That outcome will be
reported.

---

## Status

⬜ values.json generated · ⬜ stimuli rendered and visually checked ·
⬜ harness frozen · ⬜ core arm · ⬜ robustness arm · ⬜ analysis
